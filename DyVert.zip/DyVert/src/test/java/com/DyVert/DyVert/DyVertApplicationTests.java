package com.DyVert.DyVert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DyVertApplicationTests {

	@Test
	void contextLoads() {
	}

}

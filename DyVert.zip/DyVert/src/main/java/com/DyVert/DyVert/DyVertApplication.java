package com.DyVert.DyVert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DyVertApplication {
    
	public static void main(String[] args) {
		SpringApplication.run(DyVertApplication.class, args);
	}

}
